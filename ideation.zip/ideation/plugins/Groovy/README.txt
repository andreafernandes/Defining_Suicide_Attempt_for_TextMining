This directory contains code for integrating Groovy scripting into GATE.

Groovy is a Java-based scripting language, described at
http://groovy.codehaus.org Some example scripts can be found in the
resources/scripts directory

The source code in this directory is licensed under the GNU LGPL, a copy of
which can be found in LICENSE.LGPL in this directory.

The distribution includes a copy of the Groovy embedded library, in the lib
directory. This library is licensed under the Apache License, version 2.0, as
described in the files LICENSE.APACHE and NOTICE.APACHE, both in this
directory.
